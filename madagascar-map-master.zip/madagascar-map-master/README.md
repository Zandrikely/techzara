# Madagascar-map

Lisitr'ireo fokontany, kaominina , distrika eto Madagasikara.

## Zavatra mila atao :

- Mametraka ny fifandraisan'ireo kaominina sy fokontany.

- Fanadiovana ny `données`


**Code for fun !**
